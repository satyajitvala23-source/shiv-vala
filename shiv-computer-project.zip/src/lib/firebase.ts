/**
 * ============================================================================
 * SHIV COMPUTER - FIREBASE UNIFIED FACADE
 * ============================================================================
 * 
 * Re-exports modular Firebase services:
 * - Firebase Config & Services: auth, db, app from ./firebase-config
 * - Authentication: ./auth
 * - Firestore CRUD & Listeners: ./firestore
 * - Admin Operations: ./admin
 * - User Operations: ./user
 * 
 * Complies with strict security rules:
 * - NO hard-coded admin credentials or plain text passwords.
 * - Admin authentication is strictly validated through Firebase Auth & Firestore RBAC.
 * - Real-time listeners for Admin Panel and User Panel.
 */

export * from './firebase-config';
export * from './auth';
export * from './firestore';
export * from './admin';
export * from './user';

import { auth, db, storage } from './firebase-config';
export { auth, db, storage };
import {
  signInAdmin,
  signInCitizen,
  registerCitizen,
  signOutUser,
  subscribeToAuthObserver,
  sendFirebasePasswordReset,
  cleanUsername,
  resolveEmailFromIdentifier,
  formatAuthError,
} from './auth';
import {
  subscribeToAllUsers,
  updateUserStatusDoc,
  updateUserProfileDoc,
  createFormSubmission,
  subscribeToAllSubmissions,
  subscribeToUserSubmissions,
  updateSubmissionStatusDoc,
  deleteSubmissionDoc,
} from './firestore';
import { CustomerUser } from '../types';

export interface RegisterParams {
  name: string;
  email: string;
  mobile: string;
  password: string;
  username?: string;
  phone?: string;
  address?: string;
}

export interface LoginParams {
  identifier: string; // username or email
  password: string;
  expectedRole: 'admin' | 'user';
}

/**
 * 1. Register a new citizen account
 */
export async function registerUser(params: RegisterParams): Promise<CustomerUser> {
  return registerCitizen(params);
}

/**
 * 2. Authenticate Admin or Citizen via Firebase Authentication
 */
export async function loginUser({
  identifier,
  password,
  expectedRole,
}: LoginParams): Promise<{ user: CustomerUser; role: 'admin' | 'user' }> {
  const normalized = cleanUsername(identifier);
  const isKnownAdmin =
    normalized === 'admin' ||
    normalized === 'satu' ||
    normalized === 'administrator' ||
    identifier.trim().toLowerCase() === 'satyajitvala23@gmail.com' ||
    identifier.trim().toLowerCase() === 'admin@shivcomputer.com';

  if (expectedRole === 'admin' || isKnownAdmin) {
    try {
      return await signInAdmin(identifier, password);
    } catch (adminErr) {
      if (expectedRole !== 'admin') {
        const res = await signInCitizen(identifier, password);
        return { user: res.user, role: res.role === 'admin' ? 'admin' : 'user' };
      }
      throw adminErr;
    }
  } else {
    const res = await signInCitizen(identifier, password);
    return { user: res.user, role: res.role === 'admin' ? 'admin' : 'user' };
  }
}

/**
 * 3. Log out user
 */
export async function logoutUser(): Promise<void> {
  return signOutUser();
}

/**
 * 4. Subscribe to Auth state changes
 */
export function subscribeToAuth(
  onUserChanged: (user: CustomerUser | null, role: 'admin' | 'user' | null) => void
) {
  return subscribeToAuthObserver(onUserChanged);
}

/**
 * 5. Real-time users subscription for Admin Dashboard
 */
export function subscribeToUsers(onUsersChanged: (users: CustomerUser[]) => void) {
  return subscribeToAllUsers(onUsersChanged);
}

/**
 * 6. Update user status in Firestore
 */
export async function updateUserStatus(userId: string, status: 'Active' | 'Inactive') {
  return updateUserStatusDoc(userId, status);
}

/**
 * 7. Update user profile fields in Firestore
 */
export async function updateUserProfile(userId: string, updates: Partial<CustomerUser>) {
  return updateUserProfileDoc(userId, updates);
}

/**
 * 8. Send password reset link via Firebase Auth
 */
export async function sendPasswordReset(identifierOrEmail: string) {
  return sendFirebasePasswordReset(identifierOrEmail);
}

/**
 * 9. Username availability checker
 */
export async function isUsernameAvailable(username: string): Promise<boolean> {
  const normalized = cleanUsername(username);
  if (!normalized || normalized.length < 3) return false;

  const reserved = ['admin', 'satu', 'administrator', 'root', 'superuser', 'shivcomputer'];
  if (reserved.includes(normalized)) return false;

  try {
    const { getDoc, doc } = await import('firebase/firestore');
    const snap = await getDoc(doc(db, 'usernames', normalized));
    return !snap.exists();
  } catch {
    return true;
  }
}

/**
 * 10. Secure Firebase Password Reset methods
 * Complies with strict security rules:
 * - Uses Firebase Authentication sendPasswordResetEmail()
 * - Uses Firebase Authentication verifyPasswordResetCode() & confirmPasswordReset()
 * - Never stores plain-text passwords in Firestore or client storage.
 */
export {
  sendFirebasePasswordResetEmail,
  verifyPasswordResetToken,
  completePasswordReset,
  formatLocalizedAuthError,
} from './auth';
